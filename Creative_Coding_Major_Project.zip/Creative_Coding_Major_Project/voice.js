
let isMicOn = false; 
const mic = new Tone.UserMedia();
const meter = new Tone.Meter();

let meterInterval = null;
let isVoiceStarted = false; // set initial state

document.getElementById('voice').addEventListener('click', function() {
    isVoiceStarted = !isVoiceStarted; // when click, change the button text

    if (isVoiceStarted) {
        this.value = "S t o p";
    } else {
        this.value = "S t a r t";
    }
});

document.getElementById('voice').addEventListener('click', function() {

    if (isMicOn) {

        mic.close();
        clearInterval(meterInterval); 


    } else {

        mic.open().then(() => {
            mic.connect(meter);
   

            meterInterval = setInterval(() => {  
                // uset meter to get the volume of voice
                volume = meter.getValue();  
                console.log(volume);

            }, 1000);
        }).catch(e => {
            console.error('Failed to open microphone.', e);
        });
    }
    isMicOn = !isMicOn;

})

export let volume;


