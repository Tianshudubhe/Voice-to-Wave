import * as THREE from 'three'
import { volume } from './voice.js';
import { GUI } from 'https://threejsfundamentals.org/threejs/../3rdparty/dat.gui.module.js'

let waveAmplitude = 1; 
let guiWaveAmplitude = false; // waveAmplitude of gui control

function volumeToWaveAmplitude(volume) {
    if (volume <= -30) {
        return 1;
    } else {
        //  volume (-30 to 0)  -  waveAmplitude (1 to 10)
        let vol = THREE.MathUtils.clamp(volume, -30, 0); // Clamp volume between -30 and 0
        //mapLinear(value, inMin, inMax, outMin, outMax) is a function in Three.js that maps the value from the input range [inMin, inMax] to the output range [outMin, outMax]
        let waveAmplitude = THREE.MathUtils.mapLinear(vol, -30, 0, 1, 10);
        return waveAmplitude;
    }
}

let initialMusicVolume = -20;
let targetMusicVolume = 10;
let duration = 3;
let isIncreasingVolume = false;
let keepMaxVolumeTimer = null;

let isMusicPlaying = false; 

const music = new Tone.Player("wave.mp3");
music.volume.value = initialMusicVolume;
music.loop = true;

let gain = new Tone.Gain().toDestination(); // create volume control
//Connecting the music player to the volume control
music.connect(gain); 

document.getElementById('music').addEventListener('click', async function() {
    // call Tone.start()
    await Tone.start();
    if (music.state === "started") {
        music.stop();
    } else {
        music.start();
        waveAmplitude = 1; // reset value of waveAmplitude when music start 
        guiWaveAmplitude = false; 
    }
    isMusicPlaying = !isMusicPlaying;
});

//change the button text when click it
let isVoiceStarted = false; 
document.getElementById('music').addEventListener('click', function() {
    isVoiceStarted = !isVoiceStarted; 

    if (isVoiceStarted) {
        this.value = "R e p l a y";
    } else {
        this.value = "M u s i c";
    }
});

//every 200ms to check once
const volumeControl = setInterval(() => {
    if(volume > -20 && !isIncreasingVolume) {
        // If the input volume is greater than -20 dB and the current music volume is not increasing
        isIncreasingVolume = true;
        // 3s get to the max
        music.volume.rampTo(targetMusicVolume, duration());
        // after 3s
        setTimeout(() => {
            // 2s after，volume of music go down
            keepMaxVolumeTimer = setTimeout(() => {
                // 2s get to the min
                music.volume.rampTo(initialMusicVolume, duration());
                isIncreasingVolume = false;
            }, 2000);
        }, duration() * 1000);
    } 
    //The input volume is less than or equal to -20 dB and the current music volume is increasing
    else if(volume <= -20 && isIncreasingVolume) {

        clearTimeout(keepMaxVolumeTimer);
        music.volume.rampTo(initialMusicVolume, duration());
        isIncreasingVolume = false;
    }
}, 200);


const gui = new GUI()
gui.close(); 

const myObject = {
    waveAmplitude: 1,
    musicVolume: -20
};

gui.add( myObject, 'waveAmplitude', 0, 10 ).onChange(value => {
    waveAmplitude = value; // update 
    guiWaveAmplitude = true; // user change the value of waveAmplitude in GUI
    updatePlane();
})

gui.add( myObject, 'musicVolume', -20, 10).onChange(value=>{
    gain.gain.value = Math.pow(10, value / 20);
})



const planeW = 200
const planeH = 200
const planeSW = 150
const planeSH = 150

var w = window.innerWidth;
var h = window.innerHeight;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 1000);

// Setting camera position
camera.position.set(0, 0, 50);
scene.add(camera);

 // Initialising the renderer
    
const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: true,
    preserveDrawingBuffer: true,
});

// Size
renderer.setSize(window.innerWidth, window.innerHeight);
//background
renderer.setClearColor(0x6fa8dc, 1)

// put the renderer into the div make sure our project can reach to responsive design
const container = document.getElementById('renderer');
container.appendChild(renderer.domElement);


      

const planeGeometry = new THREE.PlaneGeometry(500, 400, 80, 80);


const planeMaterial = new THREE.MeshLambertMaterial(
    {color: 0xeeeff, 
    side: THREE.DoubleSide,
    wireframe:false,
});
    

// Some useless codes show our try to input an ugly model TuT
// // Input objmodel

// const loader = new OBJLoader();
// loader.load(
// "model/island.obj",
// function(object) {
//   scene.add(object);
// },
// function(xhr) {
//   console.log((xhr.loaded / xhr.total * 100) + '% loaded');
// },
// function(error) {
//    console.log('An error happened', error);
// }
// );

// let mtlLoader = new MTLLoader();
// mtlLoader.setPath('model/');
// mtlLoader.load('model.mtl', function(materials) {
// // Create a new OBJLoader
// let objLoader = new OBJLoader();

// // set material
// objLoader.setMaterials(materials);

// objLoader.setPath('model/');


// objLoader.load('island.obj', function(object) {
// scene.add(object);
// });
// });


//Vertical Light
const verLight = new THREE.DirectionalLight(0xffffff, 0.1);
verLight.position.set(-100, 100, 10);
scene.add(verLight);

//Parallel Light
const ParLight = new THREE.DirectionalLight(0xffffff,0.1);
ParLight.position.set(-500, 40, 200);
scene.add(ParLight);


//Set Plane
const plane = new THREE.Mesh(planeGeometry, planeMaterial);
plane.rotation.x = - Math.PI /  1.4
scene.add(plane);
let clock = new THREE.Clock();
let FPS = 60
let renderT = 1/FPS;
var timeS = 0;


//light
const r = -100
const y = -12
const lightDistance = -1500

//create ma
let conf = {
    lightIntensity: 0.5,
    lightColors: [0x0600ff, 0x00eaff, 0x00ff1e, 0x94007b]
}

let lights = [];

// Create and add lights to the scene
for (let i = 0; i < 4; i++) {
    let light = new THREE.PointLight(conf.lightColors[i], conf.lightIntensity, lightDistance);
    light.position.set((i%2===0)?0:r, y, (i<2)?r:-r);
    scene.add(light);
    lights.push(light);
}

//update light
function updateLights(){
    const time = Date.now() * 0.001
    const d = 10
    for (let i = 0; i < 4; i++) {
        lights[i].position.x = Math.sin(time * 0.1 * (i + 1)) * d;
        lights[i].position.z = Math.cos(time * 0.2 * (i + 1)) * d;
    }
}


function update(){
    updatePlane()
    updateLights()
}

// Update
var simplex = new SimplexNoise()
var offsetX = 0
var offsetY = 0


function updatePlane() {
    let pos = planeGeometry.attributes.position.array
    offsetX += 0.01
    offsetY = 0

    // if volume has not been set, let waveAmplitude equal 1
    
    if (!guiWaveAmplitude) {
        if (volume === undefined) {
            waveAmplitude = 1;
        } else {
            waveAmplitude = volumeToWaveAmplitude(volume);
        }
    }
    // every 3 points means one group ---> (x,y,z)
    for(let i = 0; i < pos.length; i+=3) {
        let x = pos[i]
        let y = pos[i+1]

        let dx = planeW / planeSW;
        let dy = planeH / planeSH;

        let row = Math.floor((y+10) / dy)
        let col = Math.floor((x+10) / dx)

        let tx = offsetX
        let ty = offsetY

        tx += row * 0.1
        ty += col * 0.1
        // change z value of the point to generate the wave
        // the simplex noise is an algorithm like perlin noise, it can create smoother wave than perlin noise.
        pos[i+2] = simplex.noise2D(tx, ty) * waveAmplitude

    }
    planeGeometry.attributes.position.needsUpdate = true
}

function resizeWindow(){
    w = window.innerWidth
    h = window.innerHeight
    renderer.setSize(w, h)
    camera.aspect = w / h
    camera.updateProjectionMatrix()
}

function render() {
    requestAnimationFrame(render); //generate every frame animation of the render
    var T = clock.getDelta();
    timeS = timeS + T;
    //check the time of render
    if (timeS > renderT) {
    
    renderer.render(scene, camera); 
    timeS = 0;
    update()
    resizeWindow()
    }
}
render()