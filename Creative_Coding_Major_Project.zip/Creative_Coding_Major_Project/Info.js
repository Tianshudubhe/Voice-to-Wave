//using button click to active more information for the users 
//we dont want to lose the Immersion of our project

document.getElementById("Inf").addEventListener("click", function() {
    var detail = document.getElementById("detail");
    if (detail.classList.contains('visible')) {
        detail.classList.remove('visible');
        detail.classList.add('hidden');
    } else {
        detail.classList.remove('hidden');
        detail.classList.add('visible');
    }
});

document.getElementById("Ins").addEventListener("click", function() {
    var detail = document.getElementById("step");
    if (detail.classList.contains('visible')) {
        detail.classList.remove('visible');
        detail.classList.add('hidden');
    } else {
        detail.classList.remove('hidden');
        detail.classList.add('visible');
    }
});

